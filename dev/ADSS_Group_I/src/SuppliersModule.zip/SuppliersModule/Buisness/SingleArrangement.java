package SuppliersModule.Buisness;

public class SingleArrangement extends Arrangement {


    public SingleArrangement(boolean _selfPickup,  int supplierId) {
        super(_selfPickup, supplierId);
    }
}
